package com.bloombrain.app;

public class VideoItem {
  String Video;
}


/* Location:              C:\Users\lenovo\Desktop\dex2jar\classes-dex2jar.jar!\com\bloombrain\app\VideoItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */