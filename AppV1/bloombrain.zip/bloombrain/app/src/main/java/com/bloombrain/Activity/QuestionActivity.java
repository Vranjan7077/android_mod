package com.bloombrain.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.bloombrain.R;

public class QuestionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_question);
    }
}